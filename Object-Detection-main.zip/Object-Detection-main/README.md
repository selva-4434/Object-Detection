# Jarvis
Jarvis, an Object detection system which can identify multiple objects from images, videos, or in realtime webcam too!
